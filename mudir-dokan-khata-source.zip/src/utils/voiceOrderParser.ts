import { UnitType } from '../types';

export interface ParsedVoiceItem {
  raw: string;
  productQuery: string;
  quantity: number;
  unit: UnitType;
}

// Convert Bengali numerals to English numerals
export const banglaToEnglishNumber = (str: string): string => {
  const banglaDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return str.replace(/[০-৯]/g, (match) => banglaDigits.indexOf(match).toString());
};

export const parseVoiceCommand = (transcript: string): ParsedVoiceItem | null => {
  if (!transcript || !transcript.trim()) return null;

  let text = transcript.toLowerCase().trim();
  text = banglaToEnglishNumber(text);

  // Remove common prefix phrases
  text = text.replace(/^(দয়া করে|প্লিজ|please|add|যোগ কর|যোগ করুন|আমাকে|দাও|দেও)\s+/i, '');

  // Look for quantity and unit patterns
  // e.g. "2 kg rice", "500 gm চিনি", "১ লিটার সয়াবিন তেল", "2 packet biscuit", "4 piece dim"
  const regex = /([\d.]+)\s*(kg|কেজি|গ্রাম|গ্রামের|gm|g|লিটার|লিতার|litre|liter|l|প্যাকেট|packet|হালি|পিস|টা|piece|pcs|বক্স|box)?\s*(.+)/i;
  const match = text.match(regex);

  if (match) {
    let rawQty = parseFloat(match[1]) || 1;
    const rawUnit = (match[2] || '').toLowerCase();
    let productQuery = (match[3] || '').trim();

    let unit: UnitType = 'kg';
    if (rawUnit.includes('কেজি') || rawUnit === 'kg') {
      unit = 'kg';
    } else if (rawUnit.includes('গ্রাম') || rawUnit === 'gm' || rawUnit === 'g') {
      // If user says 500gm, convert to 0.5kg for standard pricing if item is kg
      unit = 'gm';
    } else if (rawUnit.includes('লিটার') || rawUnit.includes('লিতার') || rawUnit === 'litre' || rawUnit === 'l' || rawUnit === 'liter') {
      unit = 'litre';
    } else if (rawUnit.includes('প্যাকেট') || rawUnit.includes('packet')) {
      unit = 'packet';
    } else if (rawUnit.includes('হালি')) {
      rawQty = rawQty * 4;
      unit = 'piece';
    } else if (rawUnit.includes('পিস') || rawUnit.includes('টা') || rawUnit.includes('piece') || rawUnit.includes('pcs')) {
      unit = 'piece';
    }

    // Clean product query
    productQuery = productQuery.replace(/^(এর|টা|টি|দাও|যোগ করো|যোগ করুন)\s+/i, '').trim();

    return {
      raw: transcript,
      productQuery,
      quantity: rawQty,
      unit
    };
  }

  // Fallback: If no number found, assume 1 unit of product
  return {
    raw: transcript,
    productQuery: text,
    quantity: 1,
    unit: 'piece'
  };
};
